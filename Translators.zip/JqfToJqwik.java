import java.util.*;

public class JqfToJqwik {

    public static String convert(String jqfCode) {
        StringBuilder jqwikCode = new StringBuilder();

        // Удаляем JQF-специфичные элементы
        jqfCode = jqfCode.replaceAll("@RunWith\\(JQF\\.class\\)", "")
                         .replaceAll("import org\\.junit\\.runner\\.RunWith;", "")
                         .replaceAll("import com\\.pholser\\.junit\\.quickcheck\\..*?;", "")
                         .replaceAll("import edu\\.berkeley\\.cs\\.jqf\\.fuzz\\..*?;", "");

        // Добавляем Jqwik-импорты если их нет
        if (!jqfCode.contains("import net.jqwik.api")) {
            int insertPos = jqfCode.indexOf(";") + 1;
            if (insertPos == 0) insertPos = jqfCode.indexOf("\n") + 1;
            if (insertPos == -1) insertPos = 0;
            
            jqwikCode.append(jqfCode.substring(0, insertPos))
                    .append("\nimport net.jqwik.api.*;\n")
                    .append("import org.junit.jupiter.api.Assertions;\n")
                    .append("import java.util.Arrays;\n")
                    .append(jqfCode.substring(insertPos));
        } else {
            jqwikCode.append(jqfCode);
        }

        // Основные преобразования
        jqwikCode = new StringBuilder(
            jqwikCode.toString()
                // Аннотации тестов
                .replace("@Fuzz", "@Property")
                .replace("@From(", "@ForAll(\"")
                .replace(".class)", "\")")
                
                // Типы генераторов
                .replaceAll("Generator<(.*?)>", "Arbitrary<$1>")
                
                // Генерация значений
                .replace("random.nextInt(", "Arbitraries.integers().between(")
                .replace(".array(random, ", ").array(")
                .replaceAll(", (\\d+), (\\d+)", ").ofMinSize($1).ofMaxSize($2)")
                
                // Утверждения
                .replace("assertTrue(", "Assertions.assertTrue(")
                .replace("assertEquals(", "Assertions.assertEquals(")
                .replace("assumeTrue(", "Assume.that(")
        );

        // Добавляем стандартный генератор если есть @ForAll
        if (jqwikCode.toString().contains("@ForAll") && 
            !jqwikCode.toString().contains("@Provide")) {
            
            int classPos = jqwikCode.indexOf("public class");
            int bracePos = jqwikCode.indexOf("{", classPos);
            
            if (classPos != -1 && bracePos != -1) {
                String generator = "\n\n    @Provide\n" +
                    "    Arbitrary<int[]> generateArrays() {\n" +
                    "        return Arbitraries.integers().between(-100, 1000)\n" +
                    "               .array(int[].class).ofMinSize(1).ofMaxSize(100);\n" +
                    "    }";
                
                jqwikCode.insert(bracePos + 1, generator);
            }
        }

        return jqwikCode.toString();
    }

    public static void main(String[] args) {
        String jqfTest = """
            import java.util.Arrays;
            import static org.junit.Assert.*;
            import static org.junit.Assume.*;
            
            import org.junit.runner.RunWith;
            import com.pholser.junit.quickcheck.*;
            import com.pholser.junit.quickcheck.generator.*;
            import edu.berkeley.cs.jqf.fuzz.*;
            
            @RunWith(JQF.class)
            public class ArrayTest {
                @Fuzz
                public void testSortedArraysAreOrdered(@From(ArrayGenerator.class) int[] array) {
                    assumeTrue(array.length > 0);
                    
                    int[] sorted = Arrays.copyOf(array, array.length);
                    ArrayLogic.sortWithBug(sorted);
                    
                    for (int i = 0; i < sorted.length - 1; i++) {
                        assertTrue(sorted[i] <= sorted[i + 1]);
                    }
                }
            }
            """;

        System.out.println(convert(jqfTest));
    }
}