import org.junit.Test;
import static org.junit.Assert.*;
import java.util.Arrays;

public class ArrayTestMut {
    
    @Test
    public void testSortWithBug1() {
        int[] array = {-597, -889, -1, 250, 51};
        int[] expected = {-889, -597, -1, 51, 250};
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }

    @Test
    public void testSortWithBug2() {
        int[] array = {421, -54, -89};
        int[] expected = {-89, -54, 421};
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }

    @Test
    public void testSortWithBug3() {
        int[] array = {26, 948, 20, 2, 175, 0, 225, 264, -23, -7, 44, -281, 90};
        int[] expected = {-281, -23, -7, 0, 2, 20, 26, 44, 90, 175, 225, 264, 948};
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }

    @Test
    public void testSortWithBug4() {
        int[] array = {-73, 42, 0, 674, -4, -46, 1};
        int[] expected = {-73, -46, -4, 0, 1, 42, 674};
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }

    @Test
    public void testSortWithBug5() {
        int[] array = {12, 11, -165, -13, 93, 288, -64, 506, 7, -2, -22, 2};
        int[] expected = {-165, -64, -22, -13, -2, 2, 7, 11, 12, 93, 288, 506};
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }

    @Test
    public void testSortWithBug6() {
        int[] array = {4, 965, -535, -44, -10, 181, 182};
        int[] expected = {-535, -44, -10, 4, 181, 182, 965};
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }

    @Test
    public void testSortWithBug7() {
        int[] array = {314, 420, -112, -21, -78};
        int[] expected = {-112, -78, -21, 314, 420};
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }

    @Test
    public void testSortWithBug8() {
        int[] array = {-1000, 93, 9, 33, -1, 481, -175};
        int[] expected = {-1000, -175, -1, 9, 33, 93, 481};
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }

    @Test
    public void testSortWithBug9() {
        int[] array = {-4, -292, -178, 62, 22, 110, 960};
        int[] expected = {-292, -178, -4, 22, 62, 110, 960};
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }

    @Test
    public void testSortWithBug10() {
        int[] array = {10, -220, -30, -795, -34, -33, 0, 36, 373, 379, -650, -54, -26, -815, -29, 9, 756, -11, -555, -42, -1000, 0, -366, -82, 27, 304, 58, 845, 623, 78, 109, -11, 207, 357, 124, -999, 12, 122, 276, 84, 659, -322, -2, -7, 7, 103, 31, 60, -316, -1000, -132, 522, -10, 213, -349, -110, 762, 36, -23, -90, 771};
        int[] expected = {-1000, -1000, -999, -815, -795, -650, -555, -366, -349, -322, -316, -220, -132, -110, -90, -82, -54, -42, -34, -33, -30, -29, -26, -23, -11, -11, -10, -7, -2, 0, 0, 7, 9, 10, 12, 27, 31, 36, 36, 58, 60, 78, 84, 103, 109, 122, 124, 207, 213, 276, 304, 357, 373, 379, 522, 623, 659, 756, 762, 771, 845};
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }

    @Test
    public void testSortWithBug11() {
        int[] array = {845, 4, 9, -529, -626, 1, -5, 156, -9, 219, -2};
        int[] expected = {-626, -529, -9, -5, -2, 1, 4, 9, 156, 219, 845};
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }

    @Test
    public void testSortWithBug12() {
        int[] array = {-421, 990, 2, -8};
        int[] expected = {-421, -8, 2, 990};
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }

    @Test
    public void testSortWithBug13() {
        int[] array = {-6, -254, -743, -216};
        int[] expected = {-743, -254, -216, -6};
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }

    @Test
    public void testSortWithBug14() {
        int[] array = {-43, 26, -364, 751, 1, -6, -1000, -33, 1, -9, -378, -43, 369};
        int[] expected = {-1000, -378, -364, -43, -43, -33, -9, -6, 1, 1, 26, 369, 751};
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }

    @Test
    public void testSortWithBug15() {
        int[] array = {150, -9, 25, -88, -784, 999, -11, 3, -86, -33};
        int[] expected = {-784, -88, -86, -33, -11, -9, 3, 25, 150, 999};
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }
}