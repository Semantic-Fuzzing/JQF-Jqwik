import org.junit.Test;
import static org.junit.Assert.*;
import java.util.Arrays;

public class ArrayTestMut {
    
    @Test
    public void testSortWithBug1() {
        int[] array = {764, 947, -921, 866, -942, 33, 71, 308, -665, -262, -631, -86, -663, 285, 78, 105, -582, 556, -481, -354, 313, 154, 851, -750, -408, -123, 11, 231, -797, -386, -935, 887, 91, 871, -777, 334, 13, -119, -802, -675, 282, -487, -352, 522, 173, 983, -729, 303, 217, 249, 702, -239, 866, 415, 988, 292, -335, -987, 955, 674, 101, -304, -923, -232, -539, -487, 787, 251, -138, -884, -790, -249, -763, 828, -351, -854, 345, -281, 397, -366, -325, -339, 993, -337, -986, -649, -845, 995};
        int[] expected = Arrays.stream(array).sorted().toArray();
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }

    @Test
    public void testSortWithBug2() {
        int[] array = {-778, -578, -927, -864, -109, 237, 48, 966, 538, -535, 144, 351, -283, -193, -191, 68, -329, 964, -592, 199, 411, 514, 360, -592, -772, 125, 380, -755, -84, -727, -266, -821, 727, -625, -592, -389, -595, 917, -27, -589, -529, -407, -480, -60, -832, -995, 208, 235, -249, -92, 803, -353, 563, -382, 576, -625, 964, 750, -322, -291, 752, -914, -301, -396, -89, 44, 850, -911, -358, 212, -865, 906, 19, 220, 932, 362, -908, -188, -232, 58, -868, -759, -321, 867, 635, -98};
        int[] expected = Arrays.stream(array).sorted().toArray();
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }

    @Test
    public void testSortWithBug3() {
        int[] array = {113, -951, 380, -493, -183, -32, 53, 750, -17, -456, -779, -239, 697, 138, 359, 229, 558, -873, 60, 113, 339, 810, 640, 339, -582, -416, 427, -782, 738, 307, 787, -45, 535, 492, 69, -391, -957, -846, 35, 759, -727, 383, -641, -979, -641, -528, 477, -146, 544, -693, -69, -716, 644, 165, -579, 472, -159, 193, -546, 383, -61, -455, 241, -548, -623, 866, -622, 955, 839, -569, 768, 177, 803, 582, -896, -671, -552, -303, 186, -972, 629, 509};
        int[] expected = Arrays.stream(array).sorted().toArray();
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }

    @Test
    public void testSortWithBug4() {
        int[] array = {-923, -541, 327, -526, 86, -948, 824, 490, 249, 654, -294, 934, 641, -37, -530, 707, -29, -507, -761, 388, 727, 329, 276, -621, -22, -273, 907, -459, 941, 77, -650, -273, 114, 312, -976, 650};
        int[] expected = Arrays.stream(array).sorted().toArray();
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }

    @Test
    public void testSortWithBug5() {
        int[] array = {856, -897, -751, -260, -304, 68};
        int[] expected = Arrays.stream(array).sorted().toArray();
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }

    @Test
    public void testSortWithBug6() {
        int[] array = {-398, -402, 279, -939, 980, 307, 968, 410, -135, 377, -965, -110, -863, -649, -967, -613, 4, 30, 348, -913, -539, -436, 78, 917, -107, 741, 349, 744, 48, -376};
        int[] expected = Arrays.stream(array).sorted().toArray();
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }

    @Test
    public void testSortWithBug7() {
        int[] array = {-607, 293, -835, 784, -440, 227, 651, 662, 575, -512, 250, -9, -800, 147, -965, -752, -165, 767, -533, -156, 148, -673, -405, 330, 683, 219, 420, -246, 592, -74, 155, 744, 421, 579, 140, -333, 75, -771, 431, 58, -541, -794, -456, -273, 446, 39, 158, 4, 825, -407, 442, -949, 197, -610, -257, 641, -103, 177, -467, 762};
        int[] expected = Arrays.stream(array).sorted().toArray();
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }

    @Test
    public void testSortWithBug8() {
        int[] array = {-513, -881, -292, -390, 716, -489, -124, 130, 626, -894, -158, 86, -14, 297, 677, -620, 232, 167, 272, 109, -166, 287, -959, 389, 853, -407, 471, -304, 957, 133, -206, -788, -61, 110, -757, -382, -703, 522, 125, -67, -69, -764, 412, 557, 667, 3, -828, 712, -292, 283, 47, -909, -626, 849, -787, -45, 148, -282, 914, 29};
        int[] expected = Arrays.stream(array).sorted().toArray();
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }

    @Test
    public void testSortWithBug9() {
        int[] array = {25, -653, 63, 743, -377, 485, 9, -422, 699, 134, 945, 2, 147, -598, -70, 819, 409, -426, -760, 205, -64, 534, -518, -117, -76, -329, -980, 864, -808, 244, 268, 583, 626, -302, 291, -182, -709, -574, 560, 480, -2, 922, -239, 473, 55, 780, 551, 958, 881, -22, -862, -226, -56, -889, 695, 975, -511, -128, -724, 732, 719, -739, 100, -545, -942, -307, 631, -631, -433, -926, 484, -300, -222, -191, -572, 661, -949, 776, -245, -693, -247, -768, 809, -103, 968};
        int[] expected = Arrays.stream(array).sorted().toArray();
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }

    @Test
    public void testSortWithBug10() {
        int[] array = {256, -63, -274, 666, -26, 479, 179, 90, 750, -318, 474, 21, -827, -470, -292, -803, 934};
        int[] expected = Arrays.stream(array).sorted().toArray();
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }

    @Test
    public void testSortWithBug11() {
        int[] array = {581, 217, -945, 499, 531, 819, -685, 411, 275, 605, 769, 240, 340, 241, -588, 15, -251, -753, 818, -895, -633, -518, -467, -618, -962, -411, -373, 702, -307, -416, 210, -585, 111, 556, 475, 851, -477, 133, 794, -343, 93, 806, -190, 442, -850, 39, -495, -976, 587, -549, -401, 266, -590, 930, -72, -34, -541, 61, -15, 338, 835, -314, 394, -792, 983, -856, 846, 508, 778, -873, 738, -782, 948, -251, 887, 872, 823, 416, -789, 420, 267, 50, 203, -398, -244, -99, -564, 163, -490, -409, -236, -223, 768, 715, -101, 432, 588, -504, 837};
        int[] expected = Arrays.stream(array).sorted().toArray();
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }

    @Test
    public void testSortWithBug12() {
        int[] array = {921, 741, -294, -866, -701, 261, -480, 48, 596, 311, 106, 993, -899, 937, -654, 119, 81, 669, 555, -627, 655, 494, -295, -374, 572, 823, -746, -176, 641, 558, 840, 777, -663, -439, -26, -106, -410, -171, -774, -895, -652, -987, -822, 664, -51, 221, 523, -334, 298, 760, 225, -102, -385, 809, -182, -128, -465, 152, 727, 964, 382, 549, 404, -189, -218, 230, -565};
        int[] expected = Arrays.stream(array).sorted().toArray();
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }

    @Test
    public void testSortWithBug13() {
        int[] array = {-942, -809, 366, 703, -967, -293, 507, -272, 52, 301, -117, -124, -105, -341, 314, 614, -795, 483, -373, -197};
        int[] expected = Arrays.stream(array).sorted().toArray();
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }

    @Test
    public void testSortWithBug14() {
        int[] array = {-491, -992, -330, -485, 240, 804, -859, -796, 953, -799, 896, -175, -497, 910, -167, -686, -485, -430, -758, 429, 176, 917, -22, -253, 375, -546, 372, 965, 576, 5, 49, -184, 570, 733, 810, 173, 461, 391, 363, 762, 278, -560, -263, 102, 947, 840, -848, 97, 541, 853, -178, -974, 125, 792, -908};
        int[] expected = Arrays.stream(array).sorted().toArray();
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }

    @Test
    public void testSortWithBug15() {
        int[] array = {71, -282, 885, -252, -681, 137, 851, 117, 896};
        int[] expected = Arrays.stream(array).sorted().toArray();
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }
}