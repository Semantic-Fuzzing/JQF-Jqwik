import java.lang.reflect.*;
import java.util.*;
import java.util.stream.*;

public class JqwikToJQF {

    public static String convert(String jqwikCode) {
        StringBuilder jqfCode = new StringBuilder();

        // Замена аннотаций
        jqwikCode = jqwikCode.replace("@Property", "@Fuzz")
                             .replace("@ForAll(\"", "@From(")
                             .replace("@Provide", "// @Provide → Реализуется через Generator");

        // Замена Arbitrary<T> на Generator<T>
        jqfCode.append(jqwikCode.replaceAll(
            "Arbitrary<(.*?)>", 
            "Generator<$1>"
        ));

        // Замена Arbitraries → Генерация через SourceOfRandomness
        jqfCode = new StringBuilder(
            jqfCode.toString()
                .replace("Arbitraries.integers().between(", "random.nextInt(")
                .replace(").array(", ").array(random, ")
                .replace(").ofMinSize(", ", ")
                .replace(").ofMaxSize(", ", ")
        );

        return jqfCode.toString();
    }

    public static void main(String[] args) {
        String jqwikTest = """
            @Property(tries = NUMBER_OF_TESTS)
    void sortedArraysAreOrdered(@ForAll("generateArrays") int[] array) {

        if (array.length == 0) {
            return; // Пустой массив считается отсортированным
        }
        int[] sorted = Arrays.copyOf(array, array.length);
        ErrorSort.sortWithBug(sorted);

        for (int i = 0; i < sorted.length - 1; i++) {
            Assertions.assertTrue(sorted[i] <= sorted[i + 1]);
        }


        if (testCount > 0) totalTime += duration;
        testCount++;

        if (testCount == NUMBER_OF_TESTS)
        {
            System.out.println("----------------------------------");
            double totalTimeMillis = (double) totalTime / 1_000_000;
            System.out.println("Общее время выполнения тестов: " + totalTimeMillis + " миллисекунд");
            double averageTimeMillis = (double) totalTime / (testCount-1) / 1_000_000;
            System.out.println("Среднее время выполнения теста: " + averageTimeMillis + " миллисекунд");
            System.out.println("----------------------------------");
        }
    }

    @Provide
    Arbitrary<int[]> generateArrays() {
        return Arbitraries.integers().between(-100, 1000).array(int[].class).ofMinSize(3).ofMaxSize(100);
    }
            """;

        System.out.println(convert(jqwikTest));
    }
}