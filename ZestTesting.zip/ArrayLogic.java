import java.util.Arrays;

public class ArrayLogic {
    public static int[] sortWithBug(int[] arr) {
        if (arr == null || arr.length <= 1) {
            return arr; // Ничего не делаем для null или массивов с одним элементом
        }

        int[] sorted = Arrays.copyOf(arr, arr.length);

        // Ошибка:  Меняем местами два элемента с фиксированными индексами
        if (sorted.length > 2) {
            int temp = sorted[0];
            sorted[0] = sorted[1];
            sorted[1] = temp;
        }

        return sorted;
    }
}
