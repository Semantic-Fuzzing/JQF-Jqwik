import org.junit.Test;
import static org.junit.Assert.*;

public class ArrayTestMut {
    
    @Test
    public void testSortWithBug() {
        int[] array = {3, 1, 2};
        int[] expected = {1, 2, 3};
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }
    
    @Test
    public void testEmptyArray() {
        int[] array = {};
        int[] expected = {};
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }
    
    @Test
    public void testAlreadySorted() {
        int[] array = {1, 2, 3};
        int[] expected = {1, 2, 3};
        
        ArrayLogic.sortWithBug(array);
        
        assertArrayEquals(expected, array);
    }
}