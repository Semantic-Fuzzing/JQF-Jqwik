import java.util.Arrays;
import static org.junit.Assert.*;
import static org.junit.Assume.*;

import org.junit.runner.RunWith;
import com.pholser.junit.quickcheck.*;
import com.pholser.junit.quickcheck.generator.*;
import edu.berkeley.cs.jqf.fuzz.*;

@RunWith(JQF.class)
public class ArrayTest {

    @Fuzz
    public void testSortedArraysAreOrdered(@From(ArrayGenerator.class) int[] array) {
        // Предполагаем, что массив непустой (если нужно)
        assumeTrue(array.length > 0);

        // Копируем и сортируем массив
        int[] sorted = Arrays.copyOf(array, array.length);
        ArrayLogic.sortWithBug(sorted);

        // Проверяем, что массив действительно отсортирован
        for (int i = 0; i < sorted.length - 1; i++) {
            assertTrue(sorted[i] + " должно быть <= " + sorted[i + 1], 
                      sorted[i] <= sorted[i + 1]);
        }
    }
}
