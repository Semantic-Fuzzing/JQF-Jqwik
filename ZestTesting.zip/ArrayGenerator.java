import com.pholser.junit.quickcheck.generator.GenerationStatus;
import com.pholser.junit.quickcheck.generator.Generator;
import com.pholser.junit.quickcheck.random.SourceOfRandomness;

public class ArrayGenerator extends Generator<int[]> {

    public ArrayGenerator() {
        super(int[].class);  // Должен быть первым оператором!
    }

    @Override
    public int[] generate(SourceOfRandomness random, GenerationStatus status) {
        int size = random.nextInt(3, 100);
        int[] array = new int[size];

        for (int i = 0; i < size; i++) {
            array[i] = random.nextInt(-1000, 1000);
        }

        return array;
    }
}