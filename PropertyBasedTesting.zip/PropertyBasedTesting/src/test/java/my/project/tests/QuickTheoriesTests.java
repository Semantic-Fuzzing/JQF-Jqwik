package my.project.tests;

import org.junit.jupiter.api.Test;
import org.quicktheories.QuickTheory;
import org.quicktheories.generators.SourceDSL;
import org.quicktheories.core.Gen;
import org.quicktheories.generators.Generate;

import java.util.Arrays;

import static org.quicktheories.generators.SourceDSL.integers;

public class QuickTheoriesTests {

    private static long totalTime = 0;
    private static int testCount = 0;
    private static final int NUMBER_OF_TESTS = 1000; // Default value. Set via command line argument
    private static final int MIN_SIZE = 3;
    private static final int MAX_SIZE = 100;
    private static final int MIN_VALUE = -1000;
    private static final int MAX_VALUE = 1000;

    @Test
    public void sortedArraysAreOrdered() {
        try {
            QuickTheory.qt()
                    .forAll(intArrays(integers().between(MIN_VALUE, MAX_VALUE), MIN_SIZE, MAX_SIZE))
                    .assuming(array -> array != null)
                    .check(array -> {
                        long startTime = System.nanoTime();
                        if (array == null || array.length == 0) { // Added null check
                            return true; // Пустой массив считается отсортированным
                        }

                        int[] sorted = Arrays.copyOf(array, array.length);
                        Arrays.sort(sorted);

                        boolean ordered = true;
                        for (int i = 0; i < sorted.length - 1; i++) {
                            if (sorted[i] > sorted[i + 1]) {
                                ordered = false;
                                break;
                            }
                        }

                        long endTime = System.nanoTime();
                        long duration = (endTime - startTime);

                        if (testCount > 0) totalTime += duration;
                        testCount++;

                        // Выводим результаты после каждого теста
                        if (testCount == NUMBER_OF_TESTS) {
                            System.out.println("----------------------------------");
                            System.out.println("Тест #" + testCount);
                            System.out.flush();
                            double totalTimeMillis = (double) totalTime / 1_000_000;
                            System.out.println("Общее время выполнения тестов qt: " + totalTimeMillis + " миллисекунд");
                            double averageTimeMillis = (double) totalTime / (testCount - 1) / 1_000_000;
                            System.out.println("Среднее время выполнения теста qt: " + averageTimeMillis + " миллисекунд");
                            System.out.println("----------------------------------");
                        }
                        // ... (код теста) ...
                        return ordered;
                    });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private static Gen<int[]> intArrays(Gen<Integer> elementGen, int minSize, int maxSize) {
        Gen<Integer> sizes = Generate.range(minSize, maxSize);
        return Generate.intArrays(sizes, elementGen);
    }
}