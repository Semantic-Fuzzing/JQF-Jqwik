package my.project.tests;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class JUnitTestsFromData {

    private static final String DATA_FILE = "generated_arrays.txt";

    // Метод, который предоставляет данные для параметризованного теста
    static Stream<int[]> arrayProvider() {
        try (BufferedReader reader = new BufferedReader(new FileReader(DATA_FILE))) {
            // Собираем все данные в список
            List<int[]> arrays = reader.lines()
                    .map(line -> line.substring(1, line.length() - 1)) // Убираем квадратные скобки
                    .map(line -> line.split(",")) // Разделяем строку на элементы
                    .map(parts -> Arrays.stream(parts)
                            .map(String::trim) // Убираем пробелы
                            .mapToInt(Integer::parseInt)
                            .toArray())
                    .collect(Collectors.toList());

            // Создаем stream из списка
            return arrays.stream();

        } catch (IOException e) {
            e.printStackTrace(); // Выводим stack trace исключения
            return Stream.empty(); // Возвращаем пустой Stream, чтобы избежать ошибок
        }
    }

    @ParameterizedTest
    @MethodSource("arrayProvider")
    void sortedArraysAreOrdered(int[] array) {
        if (array.length == 0) {
            return; // Пустой массив считается отсортированным
        }
        int[] sorted = Arrays.copyOf(array, array.length);
        Arrays.sort(sorted);

        for (int i = 0; i < sorted.length - 1; i++) {
            Assertions.assertTrue(sorted[i] <= sorted[i + 1]);
        }
    }
}