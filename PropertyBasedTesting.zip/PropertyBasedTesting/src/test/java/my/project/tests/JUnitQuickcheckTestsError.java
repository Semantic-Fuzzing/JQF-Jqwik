package my.project.tests;

import com.pholser.junit.quickcheck.generator.InRange;
import org.junit.runner.RunWith;
import com.pholser.junit.quickcheck.runner.JUnitQuickcheck;
import com.pholser.junit.quickcheck.Property;

import static org.junit.Assert.*;

import java.util.Arrays;

@RunWith(JUnitQuickcheck.class)
public class JUnitQuickcheckTestsError {

    private static long totalTime = 0;  // Общее время выполнения всех тестов
    private static int testCount = 0;   // Количество выполненных тестов
    private static final int NUMBER_OF_TESTS = 100; // Ожидаемое количество тестов

    @Property(trials = NUMBER_OF_TESTS)
    public void sortedArraysAreOrdered(@InRange(min = "-1000", max = "1000") int[] array) {
        long startTime = System.nanoTime(); // Записываем время начала

        if (array.length == 0) {
            //System.out.println("Пустой массив");
            return; // Пустой массив считается отсортированным
        }
        int[] sorted = Arrays.copyOf(array, array.length);
        ErrorSort.sortWithBug(sorted);

        for (int i = 0; i < sorted.length - 1; i++) {
            assertTrue(sorted[i] <= sorted[i + 1]);
        }

        long endTime = System.nanoTime(); // Записываем время окончания
        long duration = (endTime - startTime);  // Время выполнения в наносекундах

        if (testCount > 0) totalTime += duration;

        testCount++;
        //System.out.println(testCount + ".   totalTime: " + totalTime + " duration: " + duration);

        // Выводим результаты, только если это последний тест
        if (testCount == NUMBER_OF_TESTS - 1) {
            System.out.println("----------------------------------");
            System.out.println("Общее время выполнения тестов: " + (double) totalTime / 1_000_000 + " миллисекунд");
            double averageTime = (double) totalTime / (testCount - 1) / 1_000_000;
            System.out.println("Среднее время выполнения теста: " + averageTime + " миллисекунд");
            System.out.println("----------------------------------");

            // Сбрасываем счетчики для следующего запуска
            totalTime = 0;
            testCount = 0;
        }
    }
}