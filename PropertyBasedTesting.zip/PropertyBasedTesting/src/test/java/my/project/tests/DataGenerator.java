package my.project.tests;

import net.jqwik.api.*;

import java.util.Arrays;
import java.io.*;

public class DataGenerator {

    private static final String DATA_FILE = "generated_arrays.txt";
    private static final int NUMBER_OF_TESTS = 100;

    // Статический блок инициализации для очистки файла перед началом генерации данных
    static {
        clearDataFile();
    }

    @Property(tries = NUMBER_OF_TESTS)
    void generateAndSaveData(@ForAll("generateArrays") int[] array) {
        saveArrayToFile(array);
    }

    @Provide
    Arbitrary<int[]> generateArrays() {
        return Arbitraries.integers().between(-1000, 1000).array(int[].class).ofMinSize(3).ofMaxSize(100);
    }

    private void saveArrayToFile(int[] array) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(DATA_FILE, true))) {
            String arrayString = Arrays.toString(array);
            writer.write(arrayString);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void clearDataFile() {
        File file = new File(DATA_FILE);
        try {
            if (file.exists()) {
                boolean deleted = file.delete();
                if (!deleted) {
                    System.err.println("Не удалось удалить файл: " + DATA_FILE);
                }
            }
            boolean created = file.createNewFile();
            if (!created) {
                System.err.println("Не удалось создать файл: " + DATA_FILE);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}