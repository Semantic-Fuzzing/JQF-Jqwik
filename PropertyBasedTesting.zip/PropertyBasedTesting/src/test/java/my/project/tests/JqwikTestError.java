package my.project.tests;

import net.jqwik.api.*;
import org.junit.jupiter.api.Assertions;
import java.util.Arrays;

public class JqwikTestError {

    private static long totalTime = 0;
    private static int testCount = 0;
    private static final int NUMBER_OF_TESTS = 100;

    @Property(tries = NUMBER_OF_TESTS)
    void sortedArraysAreOrdered(@ForAll("generateArrays") int[] array) {
        long startTime = System.nanoTime();

        if (array.length == 0) {
            return; // Пустой массив считается отсортированным
        }
        int[] sorted = Arrays.copyOf(array, array.length);
        ErrorSort.sortWithBug(sorted);

        for (int i = 0; i < sorted.length - 1; i++) {
            Assertions.assertTrue(sorted[i] <= sorted[i + 1]);
        }

        long endTime = System.nanoTime();
        long duration = (endTime - startTime);

        if (testCount > 0) totalTime += duration;
        testCount++;

        // Выводим результаты после каждого теста
        if (testCount == NUMBER_OF_TESTS)
        {
            System.out.println("----------------------------------");
            double totalTimeMillis = (double) totalTime / 1_000_000;
            System.out.println("Общее время выполнения тестов: " + totalTimeMillis + " миллисекунд");
            double averageTimeMillis = (double) totalTime / (testCount-1) / 1_000_000;
            System.out.println("Среднее время выполнения теста: " + averageTimeMillis + " миллисекунд");
            System.out.println("----------------------------------");
        }
    }

    @Provide
    Arbitrary<int[]> generateArrays() {
        return Arbitraries.integers().between(-100, 1000).array(int[].class).ofMinSize(3).ofMaxSize(100);
    }
}
